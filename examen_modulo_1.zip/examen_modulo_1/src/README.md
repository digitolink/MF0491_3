# Documentacion del examen del modulo 1

### A continuación Se documenta el codigo del examen


Lista de archivos:

* index.html
* index.js
* styles.css

Funciones de **index.js**:

```function incrementa(){...}```

Funcion para capturar el boton y disparar su manejador del evento de click

```function incrHandler(event){...}```

Manejador del evento de click sobre el boton. **Modifica el HTML** para actualizar el contador.