//variable para contabilizar los clicks del boton
let contador = 0;

/**
 * Funcion para capturar el boton y disparar su manejador del evento de click
 */
function incrementa() {
    let boton = document.querySelector("#boton");
    boton.addEventListener("click", incrHandler);
}
/**
 * Manejador del evento de click sobre el boton
 * @param {object} event 
 */
function incrHandler(event) {
    contador++;
    let parrafo = document.querySelector("#parrafo");
    parrafo.innerHTML = "Has pulsado el boton " + contador + "veces"
}

//punto de entrada
incrementa();